import React from 'react'
import NavBar from '../component/navbar'
import Register from '../component/register'
export default function RegisterPage() {
  return (
      <>
      <NavBar/>
      <Register/>
      </>
  )
}
