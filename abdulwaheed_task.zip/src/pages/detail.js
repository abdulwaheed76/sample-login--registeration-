import React from 'react'
import Detail from '../component/details'
import NavBar from '../component/navbar'

export default function DetailPage() {
  return (
      <>
      <NavBar/>
      <Detail/>
      </>
  )
}
